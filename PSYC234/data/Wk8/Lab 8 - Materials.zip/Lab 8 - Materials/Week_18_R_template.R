# your group's name here
  
library(DescTools) 
library(tidyverse)

options(scipen = 999) # shows numeric values rather than scientific notations in the output. 