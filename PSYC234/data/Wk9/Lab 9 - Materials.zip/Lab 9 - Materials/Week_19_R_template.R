# your group's name here
  
library(car)
library(DescTools) 
library(tidyverse)
library(MASS)
library(brant)

options(scipen = 999) # shows numeric values rather than scientific notations in the output. 