# Code to run the binomial test

binom.test(13, 14, 0.5)