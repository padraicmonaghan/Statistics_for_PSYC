# Week 12: Correlations 2 - Assumptions, issues and intercorrelations------

# Step 0: Clean your environment ------------------------------------------


# Step 1: Set your working directory --------------------------------------


# Step 2: Load packages ---------------------------------------------------


# Step 3: Read in the data ------------------------------------------------


# Step 4: Data wrangling --------------------------------------------------


# Step 5: Calculating descriptive statistics ------------------------------


# Step 6: Check the assumptions -------------------------------------------


# Step 7: Conduct a correlation analysis ----------------------------------


# Step 8: Intercorrelations -----------------------------------------------

