# Week 13: Lab activity 2 ------

# Step 0: Clean your environment ------------------------------------------


# Step 1: Set your working directory --------------------------------------


# Step 2: Load packages ---------------------------------------------------


# Step 3: Read in the data ------------------------------------------------


# Step 4: Calculate mean anxiety scores ------------------------------


# Step 5: Join dataframes -------------------------------------------


# Step 6: Calculate descriptive statistics ----------------------------------


# Step 7: Visualise the data ------------------------------------------------


# Step 8: Build the regression model -----------------------------------------------


# Step 9: Check the assumptions ----------------------------------------------------
