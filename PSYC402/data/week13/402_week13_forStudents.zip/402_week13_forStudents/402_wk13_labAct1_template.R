# PSYC402: Week 13 - Lab activity 1

# Our research question: Do professors' beauty score and age predict how
# students evaluate their teaching?

# Step 1: Background and set up -------------------------------------------

# Empty R environment

# Load relevant libraries

# Read in the data

# Have a look at the data


# Step 2: Descriptive statistics ----------------------------------


# Step 3: Center and standardise ------------


# Step 4: Scatterplots -----------------------------------------


# Step 5: The regression model -----------------------


# Step 6: Checking assumptions -----------------
